# gateway-ts

A minimal Node/TypeScript gateway placeholder.
- No external dependencies required to run.
- Provides a basic HTTP server proxy stub.

Run:
```bash
npm i
npm run build
node dist/index.js
```
