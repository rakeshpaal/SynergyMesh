#!/usr/bin/env bash
set -euo pipefail
echo "helm-sync: stub"
