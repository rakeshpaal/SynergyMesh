#!/usr/bin/env bash
set -euo pipefail
echo "openapi-fix: stub (format + spectral fixes)"
