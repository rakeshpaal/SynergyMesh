#!/usr/bin/env bash
set -euo pipefail
echo "open-pr: stub (would create branch+commit+PR in real bot)"
