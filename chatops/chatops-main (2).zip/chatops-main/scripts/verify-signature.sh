#!/usr/bin/env bash
set -euo pipefail
echo "verify-signature: stub"
