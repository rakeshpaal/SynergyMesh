#!/usr/bin/env bash
set -euo pipefail
echo "opa-test: stub (use opa test .config/policy ...)"
