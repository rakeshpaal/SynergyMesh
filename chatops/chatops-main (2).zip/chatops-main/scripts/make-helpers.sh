#!/usr/bin/env bash
set -euo pipefail
die(){ echo "error: $*" >&2; exit 2; }
