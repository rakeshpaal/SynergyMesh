#!/usr/bin/env bash
set -euo pipefail
echo "breaking-changes: stub-ok"
