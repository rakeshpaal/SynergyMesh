#!/usr/bin/env bash
set -euo pipefail
echo "verify-licenses: stub"
