#!/usr/bin/env bash
set -euo pipefail
echo "kubeconform: stub"
