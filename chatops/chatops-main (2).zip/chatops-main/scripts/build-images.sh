#!/usr/bin/env bash
set -euo pipefail
echo "build-images: stub (use docker buildx in real pipeline)"
