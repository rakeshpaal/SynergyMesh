# Security

- Do not commit secrets.
- Use secret scanning (gitleaks) and supply chain evidence.
- Report vulnerabilities privately.
