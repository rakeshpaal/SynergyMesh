# SLO/SLI

## Naming governance
- NCR: naming compliance rate (target >= 0.98 in prod)
- VFC: validation failure count (target = 0)
- MFR: migration failure rate (target <= 0.05)
- ARS: auto repair success rate (target >= 0.8)
