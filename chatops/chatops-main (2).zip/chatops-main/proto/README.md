# proto

Shared contracts for services.

- `proto/naming/v1/naming.proto` : naming governance events (audit/metrics)
- `proto/quality/v1/quality.proto` : quality gates report contract
